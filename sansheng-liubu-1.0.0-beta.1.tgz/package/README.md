# UAT Agent

UAT (User Acceptance Testing) 自动化代理系统

## 功能概述

- **ITCM 集成**: 自动获取 ITCM 测试用例、发送 UAT 通知
- **异步工作流**: 基于 LangGraph 的异步流程编排
- **API 服务**: Flask REST API + Swagger 文档
- **邮件通知**: 通过 ITCM post_ticket_comment API 发送通知

## 快速开始

### 1. 环境配置

```bash
# 激活虚拟环境
.venv\Scripts\python.exe -m venv .venv
.venv\Scripts\pip.exe install -r requirements.txt
```

### 2. 配置环境变量

复制 `.env.example` 为 `.env` 并配置：

```env
# ITCM 配置
ITCM_BASE_URL=https://devintranet.ap.tkelevator.com/general/
ITCM_TOKEN=your_token_here
ITCM_COMMENT_USER=UAT_Agent

# 应用配置
APP_ENV=development
ENVIRONMENT=development
UAT_FLOW_END_NODE=send_uat_notification

# 开发环境邮件重定向
UAT_ALERT_EMAIL=your_email@example.com

# API 认证
API_USERNAME=admin
API_PASSWORD=password
```

### 3. 启动服务

```bash
# 启动 Flask API 服务
.venv\Scripts\python.exe backend\server_flask.py
```

### 4. 访问服务

| 服务 | 地址 |
|------|------|
| API | http://localhost:8000 |
| Swagger 文档 | http://localhost:8000/apidocs |
| 健康检查 | http://localhost:8000/test |

认证方式：HTTP Basic Auth（默认 admin/password）

---

## 配置说明

### 环境变量

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `ITCM_BASE_URL` | ITCM API 基础地址 | - |
| `ITCM_TOKEN` | ITCM Bearer Token | - |
| `ITCM_COMMENT_USER` | ITCM 评论用户名 | UAT_Agent |
| `APP_ENV` | 应用环境 | development |
| `ENVIRONMENT` | 环境标识 | development |
| `UAT_FLOW_END_NODE` | 流程结束节点 | send_uat_notification |
| `UAT_ALERT_EMAIL` | 开发环境邮件重定向地址 | - |
| `API_USERNAME` | API 用户名 | admin |
| `API_PASSWORD` | API 密码 | password |
| `DASHSCOPE_API_KEY` | 阿里云 DashScope API Key | - |

### 流程结束节点 (UAT_FLOW_END_NODE)

可选值：
- `send_uat_notification`: 发送UAT通知后结束（常用）
- `monitor`: 监控流程结束后结束
- `pass`: UAT通过后结束（完整流程）
- `full`: 完整流程（默认值）

---

## API 接口

### 启动 UAT 流程

```bash
POST /uat/start
Authorization: Basic admin:password

{
  "itcm_id": "1796941",
  "version": "v1.0",
  "target_uat_result": "Pass",
  "simulation_config": {}
}
```

### 获取状态

```bash
GET /uat/{itcm_id}/status
Authorization: Basic admin:password
```

### 手动触发检查

```bash
POST /uat/{itcm_id}/check
Authorization: Basic admin:password
```

### 健康检查

```bash
GET /test
```

---

---

## 三省六部制 + OmO融合

### 完整权力结构

```
用户任务
    ↓
皇帝（huangdi）          战略目标、全局掌控、最终验收
    ↓
中书省（zhongshu）       规划拆解、制定计划、依赖排序
    ↓
门下省（menxia）         审核把关、质量验收、有权否决
    ↓
尚书省（shangshu）       执行调度、按序驱动六部
    ↓
六部（Skills）
├─ 吏部（yibu）         档案采集、代码扫描（read, glob, grep）
├─ 户部（hubu）         外部资源、全球审计（webfetch, websearch）
├─ 礼部（libu）         工作流协调、技能调度（skill, todowrite）
├─ 兵部（bingbu）       战术执行、系统测试（bash）
├─ 工部（gongbu）       代码实现、基础设施（edit, write, verify_edit_context）
├─ 刑部（xingbu）       代码审查、质量把关（read, grep, semantic_grep）
└─ 库部（kubu）         OpenSpec规范化、资产持久化（openspec-write）
    ↓
Plugin 自动化层
├─ 中书省中间件         动态注入领域约束 + 流水线状态
├─ 门下省中间件         验收每步输出、contract 把关
└─ Context 工程        压缩时保留流水线状态
```

### OmO融合第一阶段（Phase 1）

将 OmO 的两个核心创新融入六部系统：

| 特性 | 工具 | 改进 |
|------|------|------|
| **Hash-Anchored Edits** | `verify_edit_context` | 编辑定位成功率 6.7% → 68.3% |
| **AST-Style 语义审查** | `semantic_grep` | 文本匹配 → 结构感知分析 |

#### 工部 - Hash-Anchored Edit 强制规范

编辑前必调 `verify_edit_context` 验证 old_string 唯一性：

```
1. 构造 old_string（含前后各≥1行上下文，严格缩进匹配）
   ↓
2. verify_edit_context({ file_path, old_string })
   ├─ UNIQUE     → 直接 edit ✅
   ├─ AMBIGUOUS  → 扩展上下文 → 重新验证
   └─ NOT_FOUND  → read文件 → 更新内容
```

#### 刑部 - AST语义审查四层框架

使用 `semantic_grep` 进行结构感知分析：

| 模式 | 用途 | 输出 |
|------|------|------|
| `definition` | 找定义声明 | 接口、类、函数定义 |
| `usage` | 找调用使用 | 高风险模式（as any、Promise等） |
| `structure` | 提取代码块 | 完整函数体、类体 |
| `cross_reference` | 交叉分析 | Dead Code、资源泄漏、类型逃逸 |

**必审项**：
- ✅ Dead Code - 只定义未使用
- ✅ 异步安全 - async 函数的 await 正确性
- ✅ 资源泄漏 - subscribe/addEventListener 未取消
- ✅ 类型逃逸 - @ts-ignore、as unknown as 合理性

#### 库部 - OpenSpec 规范化工具

库部新增两个工具支持 OpenSpec 资产规范化：

**openspec_write 工具**
```
操作 init：创建新资产
├─ 创建目录：implementation/code、config、docs、archive/v1.0/
├─ 写入 proposal.md（历史记录，不可覆盖）
├─ 初始化 changelog.md（变更日志）
└─ 可选初始化 specification.md（当前规格）

操作 update：更新规格
├─ 更新 specification.md（含新版本号）
└─ 追加 changelog.md 条目

操作 archive：版本归档
├─ 创建 archive/{version}/ 目录
├─ 复制 specification.md 到归档
└─ 更新 changelog.md
```

**openspec_validate 工具**
```
验证 openspec 目录完整性
├─ 检查必需文件：proposal.md、changelog.md
├─ 检查 archive 目录结构
├─ 可选按 asset_type/asset_name 过滤
└─ 返回：{ status: "PASS"|"FAIL", total_errors, errors[] }
```

### OmO融合第二阶段（Phase 2）

第二阶段补全变更请求处理（CR Processing）和资产标准化能力：

#### CR 处理域（cr-processing）

完整的变更请求（CR）处理流水线，用于修改现有 OpenSpec 资产：

**四步流水线**：

1. **cr-proposal** - CR 提议与分析 [yibu, hubu]
   - 确认资产存在（openspec/{asset_type}/{asset_name}/）
   - 分析变更需求，评估兼容性影响
   - 输出：`cr-analysis.md`
   ```markdown
   - asset_type: service
   - current_version: 1.0
   - breaking_change: true/false
   - impacted_modules: [...]
   - complexity: low/medium/high
   ```

2. **cr-specification** - CR 规格设计 [libu, xingbu]
   - 计算新版本号（Breaking→Major↑，其他→Minor↑）
   - 更新 specification.md（含新版本、breaking_change 标注）
   - 输出：`cr-specification-diff.md`（新旧版本对比）

3. **cr-implementation** - CR 实现 [gongbu, bingbu, xingbu]
   - 修改代码（implementation/code/）
   - 运行所有测试（必须全部通过）
   - Breaking Change 时：生成 `migration-guide.md`

4. **cr-persist** - CR 版本归档 [kubu]
   - 调用 `openspec_write` 工具进行 archive
   - 更新 changelog.md
   - 验证 archive 目录结构

**全局约束**：
- ❌ 不修改 proposal.md（历史记录）
- ❌ 版本号必须递增（Major.Minor 格式）
- ❌ Breaking Change 时必须提供迁移指南
- ❌ 代码变更必须通过所有测试

**使用示例**：
```bash
# 切换到 CR 域
/switch-domain cr-processing

# 设置 CR 变量
set_variables({
  asset_type: "service",
  asset_name: "user-service",
  cr_description: "添加新的认证接口，支持 OAuth2"
})

# 查看流水线
/status

# 启动 CR 流程（由六部依次执行四个步骤）
```

#### 资产标准化初始化技能（asset-standards）

`asset-management` 域新增 `asset-standards` init_skill，在领域启动时自动注入资产定义标准：

**五类资产标准定义**：

| 资产类型 | 示例 | 特征 | 命名后缀 |
|---------|------|------|---------|
| **Service** | user-auth-service | 独立部署，有明确边界 | -service |
| **Provider** | redis-provider | 数据获取/存储/转换 | -provider |
| **DataModel** | customer-model | 核心数据结构定义 | -model |
| **UIComponent** | modal-component | 前端可复用组件 | -component |
| **Utility** | date-formatter-util | 可复用算法/工具函数 | -util / -helper |

**输出格式约束**：
- ✅ **行号绑定** - 所有代码片段标注文件路径和行号范围：`file.ts:42-67`
- ✅ **完整性** - 必须列举所有公开接口、字段、依赖
- ✅ **零幻觉** - 不得超出实际文件范围
- ✅ **版本明确** - frontmatter 必须有 `version: X.Y`

**命名规范**：
- 使用 kebab-case（小写 + 连字符）
- 禁止：模糊词（data、util、helper 无修饰）
- 禁止：框架代码混入（ion-、ng-、v- 前缀）
- 禁止：省略关键信息（参数、返回值、版本）

**验收标准**：
```
✓ 命名规范（kebab-case，有意义的后缀）
✓ 版本明确（frontmatter 有 version 字段）
✓ 接口/字段完整列举（无省略）
✓ 行号绑定准确（可直接跳转）
✓ Breaking Change 有标注
✓ 无框架耦合（理论可移植）
```

#### 并行执行协议（shangshu.md 增强）

尚书省执行调度增强了并行执行能力：

**步骤间串行 vs 步骤内并行**：
```
【步骤间串行】
   各步骤完成验收后才开始下一步
   step1 → verify ✅ → step2 → verify ✅ → step3

【步骤内并行】
   同一步骤的 uses 列表中的多个六部，同时发出 task 调用

   例：uses: [yibu, gongbu]
   ↓
   [同时发出]
   task(agent="yibu", skill="...", ...)
   task(agent="gongbu", skill="...", ...)
   ↓
   [等待全部完成]
   ↓
   [统一验收]
   @menxia verify_step(step_id)
```

**示例**：
```yaml
pipeline:
  - id: extract
    name: 并行资产提取
    skill: extract
    uses: [bingbu, gongbu]  # 同时发给两个代理
    # → 两个 task 同时执行
    # → 都完成后统一验收
```

### Domain 系统

多个工程领域配置，每个领域有独立的技能流水线：

| 域 | 描述 | 用途 |
|-----|------|------|
| **asset-management** | 从旧代码提取五份资产，零遗漏零幻觉 | 代码资产化、规范提取 |
| **reverse-engineering** | 逆向工程和代码理解 | 架构分析、技术债清单 |
| **cr-processing** | 变更请求处理，修改现有 OpenSpec 资产 | 版本管理、兼容性评估、变更追踪 |
| **video** | 视频处理（可选） | 媒体处理工作流 |

每个 domain 在 `domains/{name}/domain.yaml` 定义：
- 流水线步骤（pipeline）
- 全局约束（constraints）
- 任务变量（variables）
- 初始化技能（init_skills）

### 工作流验收体系

每个 Skill 对应 `contract.yaml`，定义验收标准：
```yaml
verify:
  - type: file_exists
    path: "specs/{module_name}/code-index.yaml"
    error_msg: "代码索引文件不存在"
  - type: command
    run: "ls -la {module_name}"
    expect: exit_code_0
```

Plugin 在 `tool.execute.after` 自动执行验收，失败则阻断下一步。

### 文件清单

#### 核心系统文件
| 文件 | 说明 |
|------|------|
| `.opencode/plugins/sansheng-liubu.ts` | Plugin：中书省注入、门下省验收、六部工具 + OmO工具（openspec_write、openspec_validate） |
| `opencode.json` | OpenCode 配置：Agent + Plugin 注册 + 命令定义 |
| `registry.json` | 运行时状态：当前领域、变量、流水线进度 |

#### 三省六部 Agent 文件
| 文件 | 说明 |
|------|------|
| `.opencode/agents/huangdi.md` | 皇帝：战略决策 |
| `.opencode/agents/zhongshu.md` | 中书省：任务规划 |
| `.opencode/agents/menxia.md` | 门下省：审核把关 |
| `.opencode/agents/shangshu.md` | 尚书省：执行调度（含并行执行协议） |
| `.opencode/agents/yibu.md` | 吏部：信息采集（read、glob、grep） |
| `.opencode/agents/hubu.md` | 户部：外部资源（webfetch、websearch） |
| `.opencode/agents/libu.md` | 礼部：工作流协调（skill、todowrite） |
| `.opencode/agents/bingbu.md` | 兵部：测试执行（bash） |
| `.opencode/agents/gongbu.md` | 工部：编码实现 + Hash-Anchored Edit（edit、write、verify_edit_context） |
| `.opencode/agents/xingbu.md` | 刑部：代码审查 + AST语义分析（read、semantic_grep） |
| `.opencode/agents/kubu.md` | 库部：资产规范化（openspec_write、openspec_validate） |

#### 领域配置文件
| 文件 | 说明 |
|------|------|
| `domains/asset-management/domain.yaml` | 资产管理域：6步流水线 + asset-standards init_skill |
| `domains/asset-management/skills/asset-standards/SKILL.md` | **新增**：五类资产标准定义、命名规范、输出格式约束 |
| `domains/reverse-engineering/domain.yaml` | 逆向工程域配置 |
| `domains/reverse-engineering/skills/{skill}/...` | 逆向工程相关 Skill |
| `domains/cr-processing/domain.yaml` | **新增**：变更请求处理域，4步流水线 |
| `domains/cr-processing/skills/cr-proposal/SKILL.md` | **新增**：CR 提议与分析 |
| `domains/cr-processing/skills/cr-proposal/contract.yaml` | **新增**：cr-proposal 验收标准 |
| `domains/cr-processing/skills/cr-specification/SKILL.md` | **新增**：CR 规格设计 |
| `domains/cr-processing/skills/cr-specification/contract.yaml` | **新增**：cr-specification 验收标准 |
| `domains/cr-processing/skills/cr-implementation/SKILL.md` | **新增**：CR 实现 |
| `domains/cr-processing/skills/cr-implementation/contract.yaml` | **新增**：cr-implementation 验收标准 |
| `domains/cr-processing/skills/cr-persist/SKILL.md` | **新增**：CR 版本归档 |
| `domains/cr-processing/skills/cr-persist/contract.yaml` | **新增**：cr-persist 验收标准 |

#### 文档文件
| 文件 | 说明 |
|------|------|
| `AGENTS.md` | 三省六部制详细说明 |
| `三省六部制工作流程详解.md` | 工作流完整追踪示例 |
| `README.md` | 本文档 |

---

## 项目结构

```
UAT Agent/
├── .opencode/
│   ├── plugins/
│   │   └── sansheng-liubu.ts             # 三省六部 + OmO Plugin
│   │                                      # 新增：openspec_write, openspec_validate
│   ├── agents/
│   │   ├── huangdi.md                    # 皇帝
│   │   ├── zhongshu.md                   # 中书省
│   │   ├── menxia.md                     # 门下省
│   │   ├── shangshu.md                   # 尚书省（+ 并行执行协议）
│   │   ├── yibu.md                       # 吏部
│   │   ├── hubu.md                       # 户部
│   │   ├── libu.md                       # 礼部
│   │   ├── bingbu.md                     # 兵部
│   │   ├── gongbu.md                     # 工部（+ Hash-Anchored Edit）
│   │   ├── xingbu.md                     # 刑部（+ AST语义审查）
│   │   └── kubu.md                       # 库部（+ OpenSpec工具）
│   ├── domains/                          # 多领域配置
│   │   ├── asset-management/             # 资产提取域
│   │   │   ├── domain.yaml               # 6步流水线 + init_skills
│   │   │   └── skills/
│   │   │       ├── scan/                 # 代码扫描
│   │   │       ├── extract/              # 资产提取
│   │   │       ├── mapping/              # UI框架映射
│   │   │       ├── behavior/             # 行为场景
│   │   │       ├── detect/               # 框架检测
│   │   │       ├── verify-consistency/   # 一致性核验
│   │   │       ├── openspec-persist/     # OpenSpec持久化
│   │   │       └── asset-standards/      # ✨ 新增：资产标准化
│   │   ├── reverse-engineering/          # 逆向工程域
│   │   │   ├── domain.yaml
│   │   │   └── skills/
│   │   │       └── project-standards/    # 项目标准
│   │   ├── cr-processing/                # ✨ 新增：变更请求域
│   │   │   ├── domain.yaml               # 4步流水线
│   │   │   └── skills/
│   │   │       ├── cr-proposal/          # CR提议分析
│   │   │       │   ├── SKILL.md
│   │   │       │   └── contract.yaml
│   │   │       ├── cr-specification/     # CR规格设计
│   │   │       │   ├── SKILL.md
│   │   │       │   └── contract.yaml
│   │   │       ├── cr-implementation/    # CR实现
│   │   │       │   ├── SKILL.md
│   │   │       │   └── contract.yaml
│   │   │       └── cr-persist/           # CR归档
│   │   │           ├── SKILL.md
│   │   │           └── contract.yaml
│   │   └── video/                        # 视频处理域（可选）
│   │       ├── domain.yaml
│   │       └── skills/
│   └── skills/                           # 当前域的 Skill 软链接
├── opencode.json                         # OpenCode 配置 + /cr-start 命令
├── registry.json                         # 运行时状态
├── AGENTS.md                             # 三省六部制说明
├── 三省六部制工作流程详解.md              # 工作流详解
├── README.md                             # 本文档
├── runner.py                             # 命令行运行器
├── backend/
│   ├── server_flask.py                   # Flask API 服务
│   ├── graph/
│   │   ├── workflow.py                   # LangGraph 工作流
│   │   └── subgraphs/                    # 工作流节点
│   ├── clients/
│   │   ├── itcm_client.py                # ITCM API 客户端
│   │   └── email_client.py               # 邮件客户端
│   └── ...
├── ai_engine/                            # AI 服务
├── scripts/                              # 工具脚本
├── storage/                              # 数据存储
├── opencode/                             # OpenSpec 资产库
│   └── {asset_type}/{asset_name}/        # 资产目录
│       ├── proposal.md                   # 资产提议（历史记录）
│       ├── specification.md              # 当前规格
│       ├── changelog.md                  # 变更历史
│       ├── implementation/code/          # 实现代码
│       ├── config/                       # 配置文件
│       ├── docs/                         # 文档
│       └── archive/v{version}/           # 版本归档
├── .env                                  # 环境配置
├── .env.example                          # 环境配置模板
└── requirements.txt                      # Python 依赖
```

---

## 快速开始指南

### 基本命令

| 命令 | 说明 | 示例 |
|------|------|------|
| `/switch-domain {domain}` | 切换到指定领域 | `/switch-domain cr-processing` |
| `/status` | 查看当前流水线状态 | `/status` |
| `/start` | 启动三省六部流程 | `/start 完成资产提取` |
| `/cr-start` | **✨ 新增**：启动 CR 变更流程 | `/cr-start asset_type=service asset_name=user-service description="新增OAuth2认证"` |

### 常用工作流

#### 1️⃣ 资产提取流程

```bash
# 切换到资产管理域
/switch-domain asset-management

# 设置模块名称
set_variables({ module_name: "payment" })

# 启动提取流程
/start 从 payment 模块提取所有资产
```

#### 2️⃣ 变更请求处理（CR）流程

```bash
# 切换到 CR 处理域
/switch-domain cr-processing

# 设置 CR 相关变量
set_variables({
  asset_type: "service",
  asset_name: "payment-service",
  cr_description: "升级支付接口，支持分期付款"
})

# 查看流水线
/status

# 或者直接用 /cr-start 命令启动
/cr-start asset_type=service asset_name=payment-service description="升级支付接口，支持分期付款"
```

#### 3️⃣ 查看验收结果

```bash
# 查看当前步骤执行状态
/status

# 手动验收指定步骤（若需要）
verify_step(step="cr-proposal")
```

### OpenSpec 工具使用

**创建新资产**：
```javascript
openspec_write({
  asset_type: "service",
  asset_name: "auth-service",
  operation: "init",
  proposal: "# 认证服务\n提供用户身份认证..."
})
```

**更新规格**：
```javascript
openspec_write({
  asset_type: "service",
  asset_name: "auth-service",
  operation: "update",
  specification: "# 新规格\n...",
  version: "1.1",
  changelog_entry: "## v1.1 - 2026-03-14\n- 新增OAuth2支持"
})
```

**验证资产格式**：
```javascript
openspec_validate()  // 验证所有资产

openspec_validate({
  asset_type: "service",
  asset_name: "auth-service"
})  // 验证特定资产
```

---

## 运行模式

### 开发模式

```bash
# 运行主流程
.venv\Scripts\python.exe backend\main.py
```

### API 服务模式

```bash
# 启动 API 服务
.venv\Scripts\python.exe backend\server_flask.py
```

### Streamlit UI

```bash
streamlit run app.py
```

---

## 依赖

核心依赖：
- langgraph >= 0.0.40
- langchain >= 0.1.0
- flask >= 2.0.0
- flask-cors >= 4.0.0
- flasgger >= 0.9.7
- dashscope >= 1.14.0
- aiosqlite >= 0.19.0

完整依赖见 `requirements.txt`

---

## 完整架构：三省六部制 + OmO融合

### 系统架构图

```
┌─────────────────────────────────────────────────────────────┐
│                       用户任务请求                            │
└────────────────────────────┬────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                    皇帝（huangdi）                            │
│        战略决策、目标设定、全局掌控、最终验收                    │
└────────────────────────────┬────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                  中书省（zhongshu）                           │
│        任务规划、计划拆解、六部调度、依赖排序                    │
└────────────────────────────┬────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                  门下省（menxia）                             │
│        审核把关、质量验收、有权否决、需求认可                    │
└────────────────────────────┬────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                 尚书省（shangshu）                            │
│        执行调度、按序驱动六部、【步骤间串行 + 步骤内并行】        │
└────────────────────────────┬────────────────────────────────┘
                             │
              ┌──────────────┼──────────────┐
              │              │              │
              ▼              ▼              ▼
         ┌────────┐   ┌────────┐   ┌────────┐
         │ 吏部   │   │ 户部   │   │ 礼部   │
         │ yibu  │   │ hubu   │   │ libu   │
         │档案采集│   │外部资源│   │工作协调│
         └────────┘   └────────┘   └────────┘
              │              │              │
              ▼              ▼              ▼
         ┌────────┐   ┌────────┐   ┌────────┐
         │ 工部   │   │ 刑部   │   │ 库部   │
         │ gongbu │   │ xingbu │   │ kubu   │
         │编码实现│   │代码审查│   │资产规范│
         └────────┘   └────────┘   └────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────┐
│              Plugin 自动化层 + OmO融合                        │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 中书省中间件：动态注入领域约束 + init_skills内容 +      │  │
│  │           流水线状态 (experimental.chat.system.transform)│  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 门下省中间件：自动执行 contract.yaml 验收检查            │  │
│  │           失败则阻断下一步 (tool.execute.after)         │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ OmO融合工具：                                          │  │
│  │  • verify_edit_context - Hash-Anchored Edit验证       │  │
│  │  • semantic_grep - AST语义感知代码搜索                 │  │
│  │  • openspec_write - OpenSpec资产创建/更新/归档         │  │
│  │  • openspec_validate - OpenSpec格式验证               │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                 多域配置系统（Domain System）                 │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ asset-management: 资产提取（6步 + asset-standards）   │  │
│  ├──────────────────────────────────────────────────────┤  │
│  │ cr-processing: 变更请求处理（4步 + 版本管理）          │  │
│  ├──────────────────────────────────────────────────────┤  │
│  │ reverse-engineering: 逆向工程（多步骤流水线）          │  │
│  ├──────────────────────────────────────────────────────┤  │
│  │ video: 视频处理（可选扩展）                           │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                    规范化资产库（OpenSpec）                   │
│  openspec/                                                   │
│  ├─ {asset_type}/                                           │
│  │  └─ {asset_name}/                                        │
│  │     ├─ proposal.md        # 资产提议（历史不可改）        │
│  │     ├─ specification.md   # 当前规格（可演进）            │
│  │     ├─ changelog.md       # 版本历史（自动记录）          │
│  │     ├─ implementation/code/ # 实现代码                   │
│  │     ├─ config/            # 配置文件                     │
│  │     ├─ docs/              # 文档资料                     │
│  │     └─ archive/           # 版本归档                     │
│  │        ├─ v1.0/           # v1.0版本快照                 │
│  │        ├─ v1.1/           # v1.1版本快照                 │
│  │        └─ v2.0/           # v2.0版本快照                 │
└─────────────────────────────────────────────────────────────┘
```

### 工作流完整周期

```
【资产提取工作流 - 三省六部运作】

皇帝:
  /switch-domain asset-management
  set_variables({ module_name: "payment" })
  /start 提取 payment 模块资产
         ↓
         task(agent="zhongshu", prompt="规划 payment 模块提取计划")

中书省:
  规划流水线：scan → extract → mapping → behavior → detect → verify → persist
         ↓
         task(agent="menxia", prompt="审核执行计划")

门下省:
  审核计划 → 通过 ✅
         ↓
         task(agent="shangshu", prompt="执行已审核的计划")

尚书省:
  分发任务给六部（【步骤间串行，步骤内并行】）

  Step 1: scan [yibu]
    task(agent="yibu", skill="scan", prompt="扫描代码")
         ↓
    task(agent="menxia", prompt="验收 scan 步骤")

  Step 2: extract [bingbu, gongbu] 【并行】
    task(agent="bingbu", skill="extract", prompt="提取资产")
    task(agent="gongbu", skill="extract", prompt="并行提取")
         ↓
    task(agent="menxia", prompt="验收 extract 步骤")

  ...（后续步骤同理）
         ↓
皇帝:
  task(agent="menxia", prompt="最终验收，获取完整资产库")


【变更请求工作流 - 三省六部运作】

皇帝:
  /cr-start asset_type=service asset_name=user-service \
            description="支持OAuth2认证"
         ↓
         task(agent="zhongshu", prompt="规划 CR 流水线")

中书省:
  规划 4 步：cr-proposal → cr-specification →
             cr-implementation → cr-persist
         ↓
         task(agent="menxia", prompt="审核 CR 计划")

门下省:
  审核 CR 计划 → 通过 ✅
         ↓
         task(agent="shangshu", prompt="执行 CR 流水线")

尚书省:
  Step 1: cr-proposal [yibu, hubu]
    task(agent="yibu", skill="cr-proposal", prompt="分析变更")
    task(agent="hubu", skill="cr-proposal", prompt="外部审计")
         ↓
    task(agent="menxia", prompt="验收 cr-proposal")

  Step 2: cr-specification [libu, xingbu]
    task(agent="libu", skill="cr-specification", prompt="规格设计")
    task(agent="xingbu", skill="cr-specification", prompt="代码审查")
         ↓
    task(agent="menxia", prompt="验收 cr-specification")

  Step 3: cr-implementation [gongbu, bingbu, xingbu]
    (三个 task 并行执行)
         ↓
    task(agent="menxia", prompt="验收 cr-implementation")

  Step 4: cr-persist [kubu]
    task(agent="kubu", skill="cr-persist", prompt="版本归档")
         ↓
    task(agent="menxia", prompt="验收 cr-persist")
         ↓
皇帝:
  task(agent="menxia", prompt="最终验收，版本递增完成")
```

### 关键创新

| 创新点 | 实现 | 收益 |
|-------|------|------|
| **Hash-Anchored Edit** | verify_edit_context 强制唯一性验证 | 编辑定位成功率 68.3% ↑ |
| **AST语义审查** | semantic_grep 结构感知分析 | 自动检测 Dead Code、资源泄漏、类型逃逸 |
| **Contract验收** | Plugin 自动执行验收检查 | 失败阻断，零遗漏验收 |
| **并行执行** | 步骤内并行（同时发多个 task） | 流程加速，提高效率 |
| **OpenSpec规范** | 资产规范化持久化库 | 版本可追溯、兼容性明确、变更历史完整 |
| **init_skills** | 领域启动自动注入标准定义 | 约束自动生效，零手动配置 |

---

## 技术栈

- **编程语言**：TypeScript、Python
- **框架**：LangGraph、Flask、Streamlit
- **AI 模型**：Claude 3 (Opus/Sonnet/Haiku)
- **工具**：OpenCode CLI、Plugin System
- **存储**：本地文件 + JSON/YAML 配置

---

## 贡献指南

### 添加新 Skill

1. 在 `domains/{domain}/skills/{skill}/` 创建目录
2. 编写 `SKILL.md`（含目的、工作流程、输出产物）
3. 编写 `contract.yaml`（含验收检查项）
4. 在 `domain.yaml` 中添加步骤引用

### 添加新 Domain

1. 创建 `domains/{domain}/domain.yaml`
2. 定义 pipeline（步骤 + uses）、constraints、variables
3. 可选：定义 init_skills
4. 创建对应的 Skill 目录结构

### 扩展 Plugin 工具

在 `.opencode/plugins/sansheng-liubu.ts` 中：
1. 定义新工具的参数和执行逻辑
2. 在 `tool:` 对象中注册
3. 指定所属的六部 Agent（通过权限配置）

---

## FAQ

**Q: 如何保证变更的向后兼容性？**
A: CR 流程第一步会自动评估 breaking_change，第四步在 changelog 中记录，便于追踪。Breaking Change 时必须生成 migration-guide.md。

**Q: 可以跳过某个步骤吗？**
A: 不可以。尚书省严格按流水线顺序执行，门下省逐步验收。这是三省六部制的核心原则。

**Q: 并行执行会有顺序问题吗？**
A: 不会。同一步骤内的任务在相同数据源上操作，互不依赖。所有任务完成后再进入下一步，确保依赖关系正确。

**Q: 如何使用 OpenSpec 资产库？**
A: 通过 openspec_write 和 openspec_validate 工具操作，或直接访问 openspec/{type}/{name}/ 目录。资产的规格、代码、配置都在此集中管理。

**Q: verify_edit_context 和 semantic_grep 区别？**
A: verify_edit_context 用于编辑前验证，semantic_grep 用于审查后分析。前者保证编辑定位准确，后者提供结构感知的代码理解。

